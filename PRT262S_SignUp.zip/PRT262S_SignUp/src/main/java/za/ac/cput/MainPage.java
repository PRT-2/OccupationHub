package za.ac.cput;
import javax.swing.*;

/**
 *
 * @author karri
 * 222574534
 */
public class MainPage extends JFrame {
    public MainPage() {
        // Placeholder content for the main page
        JLabel welcomeLabel = new JLabel("Welcome to the Main Page!");
        welcomeLabel.setBounds(50, 50, 300, 30);

        // Set layout and add components
        setLayout(null);
        add(welcomeLabel);

        // Set frame properties
        setSize(400, 200);
        setTitle("Main Page");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new MainPage();
    }
}