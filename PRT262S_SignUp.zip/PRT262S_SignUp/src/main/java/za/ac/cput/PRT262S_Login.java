package za.ac.cput;
import javax.swing.*;
import java.awt.event.*;

/**
 *
 * @author karri
 * 222574534
 */

public class PRT262S_Login extends JFrame implements ActionListener {
    // Components for the login form
    JLabel label1, label2;
    JTextField usernameField;
    JPasswordField passwordField;
    JButton loginButton, goToSignUpButton;

    public PRT262S_Login() {
        // Creating the components
        label1 = new JLabel("Username:");
        label2 = new JLabel("Password:");

        usernameField = new JTextField();
        passwordField = new JPasswordField();

        loginButton = new JButton("Login");
        goToSignUpButton = new JButton("Go to Sign Up");

        // Setting layout and adding components
        setLayout(null);
        label1.setBounds(50, 50, 100, 30);
        usernameField.setBounds(200, 50, 150, 30);
        label2.setBounds(50, 100, 100, 30);
        passwordField.setBounds(200, 100, 150, 30);

        loginButton.setBounds(50, 150, 100, 30);
        goToSignUpButton.setBounds(200, 150, 150, 30);

        // Adding components to the form
        add(label1);
        add(usernameField);
        add(label2);
        add(passwordField);
        add(loginButton);
        add(goToSignUpButton);

        // Adding action listeners
        loginButton.addActionListener(this);
        goToSignUpButton.addActionListener(this);

        // Setting the frame properties
        setSize(450, 300);
        setTitle("Login - PRT262S");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            boolean loginSuccessful = false;

            for (int i = 0; i < PRT262S_SignUp.userCount; i++) {
                if (username.equals(PRT262S_SignUp.usernames[i]) && password.equals(PRT262S_SignUp.passwords[i])) {
                    loginSuccessful = true;
                    break;
                }
            }

            if (loginSuccessful) {
                JOptionPane.showMessageDialog(this, "Login successful!");

                // Redirect to the main page placeholder
                new MainPage();  // Placeholder for the main page
                this.dispose();  // Close the login form after successful login
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials, please try again.");
            }
        } else if (e.getSource() == goToSignUpButton) {
            new PRT262S_SignUp(); // Redirect to the sign-up form
            this.dispose();   // Close the login form
        }
    }

    public static void main(String[] args) {
        new PRT262S_Login();
    }
}
