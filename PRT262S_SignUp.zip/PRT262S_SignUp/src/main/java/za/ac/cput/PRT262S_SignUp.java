package za.ac.cput;
import javax.swing.*;
import java.awt.event.*;

/**
 *
 * @author karri
 * 222574534
 */

public class PRT262S_SignUp extends JFrame implements ActionListener {
    // Components for the sign-up form
    JLabel label1, label2, label3;
    JTextField usernameField;
    JPasswordField passwordField, confirmPasswordField;
    JButton signUpButton, goToLoginButton;

    // Arrays to store users and passwords
    static String[] usernames = new String[10];
    static String[] passwords = new String[10];
    static int userCount = 0;

    public PRT262S_SignUp() {
        // Creating the components
        label1 = new JLabel("Username:");
        label2 = new JLabel("Password:");
        label3 = new JLabel("Confirm Password:");

        usernameField = new JTextField();
        passwordField = new JPasswordField();
        confirmPasswordField = new JPasswordField();

        signUpButton = new JButton("Sign Up");
        goToLoginButton = new JButton("Go to Login");

        // Setting layout and adding components
        setLayout(null);
        label1.setBounds(50, 50, 100, 30);
        usernameField.setBounds(200, 50, 150, 30);
        label2.setBounds(50, 100, 100, 30);
        passwordField.setBounds(200, 100, 150, 30);
        label3.setBounds(50, 150, 150, 30);
        confirmPasswordField.setBounds(200, 150, 150, 30);

        signUpButton.setBounds(50, 200, 100, 30);
        goToLoginButton.setBounds(200, 200, 150, 30);

        // Adding components to the form
        add(label1);
        add(usernameField);
        add(label2);
        add(passwordField);
        add(label3);
        add(confirmPasswordField);
        add(signUpButton);
        add(goToLoginButton);

        // Adding action listeners
        signUpButton.addActionListener(this);
        goToLoginButton.addActionListener(this);

        // Setting the frame properties
        setSize(450, 350);
        setTitle("Sign Up - PRT262S");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == signUpButton) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String confirmPassword = new String(confirmPasswordField.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required!");
            } else if (!password.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(this, "Passwords do not match!");
            } else if (userCount >= usernames.length) {
                JOptionPane.showMessageDialog(this, "User limit reached. Cannot sign up more users.");
            } else {
                usernames[userCount] = username;
                passwords[userCount] = password;
                userCount++;
                JOptionPane.showMessageDialog(this, "Sign up successful!");

                // Redirect to login page after successful sign-up
                new PRT262S_Login();
                this.dispose();  // Close sign-up form
            }
        } else if (e.getSource() == goToLoginButton) {
            new PRT262S_Login(); // Redirect to the login form
            this.dispose();  // Close the sign-up form
        }
    }

    public static void main(String[] args) {
        new PRT262S_SignUp();
    }
}

